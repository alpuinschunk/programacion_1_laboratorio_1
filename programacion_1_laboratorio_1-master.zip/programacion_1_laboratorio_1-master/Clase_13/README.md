# Clase 13

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* -

#### Video tutoriales:

* https://www.youtube.com/watch?v=iJG0JmpzBoc&index=13&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

       Se solicita realizar una aplicaci�n que permita administrar
       los libros de una libreria.

	    Datos Libro:
           C�digo del libro (1 a  5.000) Validar
           T�tulo  (m�ximo 50 caracteres)  Validar
           C�digo del Autor  (1 a 500)  Validar
           Stock  (numerico)

       ALTAS: No es necesario el ingreso de todos los libros.

       MODIFICAR: Se ingresar� el C�digo del Libro, permitiendo modificar:
           C�digo del libro
           T�tulo
           C�digo del Autor
           Stock

       BAJA: Se ingresa el C�digo del Libro.

       ORDENAR: Se ordenara el array por titulo y ante igualdad por codigo

       LISTAR LIBROS: Realizar un solo listado con todos los libros

- Version: 0.1 del 04 enero de 2016
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   manejo de men�
*   manejo de estructuras
*   funcion main() compacta
*   variables y funciones en Ingles
*   Alta de datos para testing