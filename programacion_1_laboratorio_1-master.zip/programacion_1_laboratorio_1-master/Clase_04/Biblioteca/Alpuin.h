int validarRangoEntero (int valor, int lInf, int lSup);
