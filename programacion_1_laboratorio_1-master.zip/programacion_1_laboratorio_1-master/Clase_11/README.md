# Clase 11

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* -

#### Video tutoriales:

* https://www.youtube.com/watch?v=dlS0vO3KNDI&index=11&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

   Desarrollar una aplicaci�n para un comercio que le permita
   administrar sus productos.

   Datos de cada producto:
       C�digo (1 a 1000) (Validar)
       Descripci�n (m�ximo 50 caracteres)  (Validar)
       Importe (Validar)
       Cantidad (Validar)

   1. ALTAS: No es necesario el ingreso de todos los productos.
   2. MODIFICAR: Se ingresar� el C�digo de Producto, permitiendo modificar:
       o Descripci�n
       o Importe
       o Cantidad
   3. BAJA: Se ingresa el C�digo de Producto y se limpiar�n los datos asociados
   4. LISTAR: Realizar un solo listado de los datos ordenados por los siguientes criterios:
       o Descripci�n (descendente)

- Version: 0.1 del 04 enero de 2016
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   manejo de men�
*   manejo de estructuras
*   funcion main() compacta
*   variables y funciones en Ingles