# Clase 17

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Memoria.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=-Rx_CvPGDow&index=17&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

    Construir una funci�n �getDynamicString� que permita al usuario
    ingresar un texto y devuelva un puntero a un espacio de memoria
    donde esta almacenado el texto ingresado.
    Se requiere el uso de memoria din�mica.

- Version: 0.1 del 16 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*   malloc, realloc, free